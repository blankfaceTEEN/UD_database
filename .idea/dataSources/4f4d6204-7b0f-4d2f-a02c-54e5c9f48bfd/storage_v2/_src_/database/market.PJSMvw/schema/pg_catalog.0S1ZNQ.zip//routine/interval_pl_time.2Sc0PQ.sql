create function interval_pl_time(interval, time without time zone) returns time without time zone
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
select $2 + $1
$$;

comment on function interval_pl_time(interval, time) is 'implementation of + operator';

alter function interval_pl_time(interval, time) owner to postgres;

